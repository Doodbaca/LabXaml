﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using laboratoire2.ViewModel;

namespace laboratoire2.Commande
{
    class QuitterCommande :ICommand
    {
        private MenuViewModel viewModel;

        public MenuViewModel ViewModel
        {
            get { return viewModel; }
        }

        public QuitterCommande(MenuViewModel viewModel)
        {
            this.viewModel = viewModel;
        }

        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }

        public bool CanExecute(object parameter)
        {
            return true;
        }
        public void Execute(object parameter)
        {
            ViewModel.QuitterCommande();
        }
    }
}
