﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace laboratoire2.Model
{
    class Animal: INotifyPropertyChanged
    {
        private string nom;
        private string typeAnimal;
        private string age;

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
        public Animal(string nom, string typeAnimal,string age)
        {
            Nom = nom;
            Type = typeAnimal;
            Age = age;
        }
        public string Nom { get { return nom; } set { nom = value; OnPropertyChanged("Nom"); } }
        public string Type { get { return typeAnimal; } set { typeAnimal = value; OnPropertyChanged("Type"); } }
        public string Age { get { return age; }set { age = value; OnPropertyChanged("Age"); } }
    }
}
