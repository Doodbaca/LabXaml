﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laboratoire2.Model
{
    class Oiseau : Animal
    {
        public Oiseau(string nom, string age) : base(nom, "Oiseau", age)
        {

        }
    }
}
