﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laboratoire2.Model
{
    class Chat : Animal
    {
        public Chat(string nom, string age) : base (nom,"Chat",age)
        {

        }
    }
}
