﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace laboratoire2.Model
{
    class Usager : INotifyPropertyChanged
    {
        private string nom;
        private bool connecter;
        public Usager(string nom )
        {
            this.nom = nom;
            connecter = false;
        }

        public string Nom { get { return nom; } set { nom = value; OnPropertyChanged("Nom"); } }
        public bool Connecter { get { return connecter; } set { connecter = value; OnPropertyChanged("Connecter"); } }
       
        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
    }
}
