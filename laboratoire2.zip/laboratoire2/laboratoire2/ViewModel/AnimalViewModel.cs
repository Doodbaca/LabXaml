﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.MobileControls;
using laboratoire2.Model;

namespace laboratoire2.ViewModel
{
    class AnimalViewModel : BaseViewModel
    {
        private List <Animal> animals = new List<Animal>() { new Chat("Tom", "79"), new Poisson("Nemo", "16"), new Oiseau("Zazou", "79") };
        private BaseViewModel viewModelActif;
        private MenuViewModel menu;
        public AnimalViewModel()
        {
            Menu = new MenuViewModel();
            viewModelActif = this;
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
        public List<Animal> Animals { get { return animals; } }
        public BaseViewModel ViewModelActif { get { return viewModelActif; } set { viewModelActif = value; OnPropertyChanged("ViewModelActif"); } }
        public MenuViewModel Menu { get { return menu; } set { menu = value; OnPropertyChanged("Menu"); } }

    }
}
