﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using laboratoire2.Model;
using laboratoire2.Commande;
using System.Windows;

namespace laboratoire2.ViewModel
{
    class MainViewModel : BaseViewModel, INotifyPropertyChanged
    {
        private Usager user;
        private BaseViewModel viewModelActif;
        private Connexion commande;
        private MenuViewModel menu;
        public MainViewModel()
        {
            User = new Usager("");
            ConnexionCommand = new Connexion(this);
            ViewModelActif = this;
            Menu = new MenuViewModel();
        }

        public void Connexion()
        {
            if(User.Nom == "Xavier")
            {
                ViewModelActif = new AnimalViewModel();
            }
            else
            {
                
            }
           
        }

        public bool PeutCeConnecter()
        {
            if(user.Nom == "")
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
        public Usager User { get { return user; } set { user = value; OnPropertyChanged("User"); } }
        public BaseViewModel ViewModelActif{ get { return viewModelActif; } set { viewModelActif = value; OnPropertyChanged("ViewModelActif"); } }
        public Connexion ConnexionCommand { get { return commande; } set { commande = value; OnPropertyChanged("ConnexionCommand"); } }
        public MenuViewModel Menu { get { return menu; } set { menu = value; OnPropertyChanged("Menu"); } }
    }
}
