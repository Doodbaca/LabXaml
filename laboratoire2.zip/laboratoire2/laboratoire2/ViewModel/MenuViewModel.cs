﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using laboratoire2.Commande;

namespace laboratoire2.ViewModel
{
    class MenuViewModel : BaseViewModel, INotifyPropertyChanged
    {
        private SauvergarderCommande save;
        private BaseViewModel viewModelActif;
        private QuitterCommande quitter;
        public MenuViewModel()
        {
            ViewModelActif = this;
            SauvegarderCommand = new SauvergarderCommande(this);
            QuitterCommand = new QuitterCommande(this);
        }
        public void SauvegarderCommande()
        {
            MessageBox.Show("Votre code a été sauvegarder","Sauvegarde");
        }

        public void QuitterCommande()
        {
            MessageBox.Show("Appuie sur le X","Quitter");

        }
        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
        public SauvergarderCommande SauvegarderCommand { get { return save; } set { save = value; OnPropertyChanged("SauvegarderCommand"); } }
        public BaseViewModel ViewModelActif { get { return viewModelActif; } set { viewModelActif = value; OnPropertyChanged("ViewModelActif"); } }
        public QuitterCommande QuitterCommand { get { return quitter; } set { quitter = value; OnPropertyChanged("QuitterCommand"); } }
    }
}
