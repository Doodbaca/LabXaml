-- Primary key	
ALTER TABLE	tblUtilisateur				ADD PRIMARY KEY (Id);
ALTER TABLE	tblJeux						ADD PRIMARY KEY (IdJeux);

--FOREIGN Key

ALTER TABLE tblJeux  		ADD FOREIGN KEY (IdJoueur) 		REFERENCES tblUtilisateur (Id);


