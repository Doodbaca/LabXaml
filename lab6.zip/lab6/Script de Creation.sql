	 Use master;	 
	 DROP DATABASE IF EXISTS Lab6Mathieu ;
	 Create Database Lab6Mathieu;
	 USE Lab6Mathieu;
	 


	 

	 
	 CREATE TABLE tblUtilisateur (
	 Id							INT					NOT NULL 		Identity(1,1),
	 Pseudo						VARCHAR(50)			NOT NULL,
	 Nom						VARCHAR(50)			NOT NULL,
	 Prenom   					VARCHAR(50)			NOT NULL,
	 MdpChiffre					VARCHAR(130)		NOT NULL,
	 Courriel					VARCHAR(1100)		NOT NULL,
	 DateDeNaissance			DATE				NOT NULL,
	 )
	 
	 CREATE TABLE tblJeux (
	 
	 IdJeux						INT					NOT NULL 		Identity(1,1),
	 CheminDacces				VARCHAR(100)		NOT NULL,
	 NomJeux					VARCHAR(50)			NOT NULL,
	 IdJoueur					INT					NOT NULL,
	 )