﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratoire6.Model
{
    class Utilisateur : INotifyPropertyChanged
    {
        private string nom;
        private string couriel;
        private string motdePasse;
        private string dateNaissance;
        private string pseudo;
        private string prenom;
        private int id;
        public Utilisateur()
        {
           
        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
        public int Id { get { return id; } set { id = value; OnPropertyChanged("Id"); } }
        public string Nom { get { return nom; } set { nom = value; OnPropertyChanged("Nom"); } }
        public string Pseudo { get { return pseudo; } set { pseudo = value; OnPropertyChanged("Pseudo"); } }
        public string Prenom { get { return prenom; } set { prenom = value; OnPropertyChanged("Prenom"); } }
        public string Couriel { get { return couriel; } set { couriel = value; OnPropertyChanged("Couriel"); } }
        public string MotdePasse { get { return motdePasse; } set { motdePasse = value; OnPropertyChanged("MotdePasse"); } }
        public string DateNaissance{ get { return dateNaissance; } set { dateNaissance = value; OnPropertyChanged("DateNaissance"); } }
       
    }
}
