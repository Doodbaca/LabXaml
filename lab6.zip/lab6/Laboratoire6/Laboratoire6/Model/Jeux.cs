﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratoire6.Model
{
    class Jeux : INotifyPropertyChanged
    {
        private string chemin;
        private string nom;
        private int idJoueur;
        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
        public string Nom { get { return nom; } set { nom = value; OnPropertyChanged("Nom"); } }
        public string Chemin{ get { return chemin; } set { chemin = value; OnPropertyChanged("Chemin"); } }
        public int IdJoueur { get { return idJoueur; }  set { idJoueur = value; OnPropertyChanged("IdJoueur"); } }

        public override string ToString()
        {
            return ""+Nom+" Chemin D'accés :" + chemin;
        }
    }
}
