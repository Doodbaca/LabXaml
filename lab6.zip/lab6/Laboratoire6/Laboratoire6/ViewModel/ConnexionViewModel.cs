﻿using Laboratoire6.Command;
using Laboratoire6.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Laboratoire6.ViewModel
{
    class ConnexionViewModel : BaseViewModel
    {

        private BaseViewModel ViewModelActif;
        private BaseCommand inscription;
        private BaseCommand connexion;
        private Utilisateur userInscription;
        private Utilisateur userConnexion;
        public ConnexionViewModel()
        {
            User = new Utilisateur();
            UserConnect = new Utilisateur();
            ViewModelActif = this;
            Predicate<object> canExecute = _ => true;
            Action<object> execute = _ => InscriptionChangementdePage();
            Inscription = new BaseCommand(execute, canExecute);
            execute = _ => identification();
            connexion = new BaseCommand(execute, canExecute);
        }
        public Utilisateur User { get { return userInscription; } private set { userInscription = value; } }
        public Utilisateur UserConnect { get { return userConnexion; } private set { userConnexion = value; } }

        public void InscriptionChangementdePage()
        {
           bool reussi =  InsererUtilisateur(User);
            if (reussi == true)
            {
                SearchUtilisateur(User);
                UserConnect = User;
                ChangementPage();
            }
            else
            {
                MessageBox.Show("Identifiant ou Mot de passe Incorecte");
            }
            
        }
        public void identification()
        {
            SearchUtilisateur(UserConnect);
            if (UserConnect.Id != 0)
            {
                ChangementPage();
            }
        }
        public void ChangementPage()
        {
            View.JeuxView newWindow = new View.JeuxView();
            newWindow.DataContext = new ListeJeuViewModel(UserConnect);
            newWindow.Show();
        }
        public BaseCommand Connexion { get { return connexion; } private set { connexion = value; } }
        public BaseCommand Inscription { get { return inscription; } private set { inscription= value; } }

    }
}
