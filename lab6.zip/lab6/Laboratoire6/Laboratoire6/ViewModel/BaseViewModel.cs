﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Laboratoire6.Model;

namespace Laboratoire6.ViewModel
{
    class BaseViewModel
    {
        public bool InsererUtilisateur(Utilisateur User)
        {
            bool reussi = true;
            try
            {
                SqlConnection con = new SqlConnection("Data Source = deptinfo420; Initial Catalog = Lab6Mathieu; Integrated Security = True");
                con.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO tblUtilisateur(Pseudo,Nom,Prenom,MdpChiffre,Courriel,DateDeNaissance) VALUES (@param1,@param2,@param3,@param4,@param5,@param6)", con);
                cmd.Parameters.Add("@param1", SqlDbType.VarChar, 50).Value = User.Pseudo;
                cmd.Parameters.Add("@param2", SqlDbType.VarChar, 50).Value = User.Nom;
                cmd.Parameters.Add("@param3", SqlDbType.VarChar, 50).Value = User.Prenom;
                cmd.Parameters.Add("@param4", SqlDbType.VarChar, 130).Value = User.MotdePasse;
                cmd.Parameters.Add("@param5", SqlDbType.VarChar, 1100).Value = User.Couriel;
                cmd.Parameters.Add("@param6", SqlDbType.Date).Value = User.DateNaissance;
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
            }
            catch(Exception e)
            {
                reussi = false;
            }
            return reussi;
        }
        public bool InsererJeux(Jeux jeux)
        {
            bool reussi = true;
            try
            {
                SqlConnection con = new SqlConnection("Data Source = deptinfo420; Initial Catalog = Lab6Mathieu; Integrated Security = True");
                con.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO tblJeux(NomJeux,CheminDacces,IdJoueur) VALUES (@param1,@param2,@param3)", con);
                cmd.Parameters.Add("@param1", SqlDbType.VarChar, 50).Value = jeux.Nom;
                cmd.Parameters.Add("@param2", SqlDbType.VarChar, 100).Value = jeux.Chemin;
                cmd.Parameters.Add("@param3", SqlDbType.Int).Value = jeux.IdJoueur;
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                reussi = false;
            }
            return reussi;
        }
        public void SearchUtilisateur(Utilisateur user)
        {
            
            try
            {
                SqlConnection con = new SqlConnection("Data Source = deptinfo420; Initial Catalog = Lab6Mathieu; Integrated Security = True");
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT * From tblUtilisateur Where Courriel = @param1 AND MdpChiffre = @param2", con);
                cmd.Parameters.Add("@param1", SqlDbType.VarChar, 1100).Value = user.Couriel;
                cmd.Parameters.Add("@param2", SqlDbType.VarChar, 130).Value = user.MotdePasse;
                SqlDataAdapter adpater = new SqlDataAdapter(cmd);
                DataSet data = new DataSet();
                adpater.Fill(data, "tblUtilisateur");

                foreach(DataRow row in data.Tables[0].Rows)
                {
                    user.Id = Convert.ToInt32(row[0].ToString());
                    user.Pseudo = row[1].ToString();
                    user.Nom = row[2].ToString();
                    user.Prenom = row[3].ToString();
                    user.DateNaissance = row[6].ToString();
                }

            }
            catch (Exception e)
            {

            }
        }
        public ObservableCollection<Jeux> ChercherJeux(Utilisateur user)
        {
            ObservableCollection<Jeux> liste = new ObservableCollection<Jeux>();
            
           
            try
            {
                
                SqlConnection con = new SqlConnection("Data Source = deptinfo420; Initial Catalog = Lab6Mathieu; Integrated Security = True");
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT NomJeux,CheminDacces From tblJeux Where IdJoueur = @param1", con);
                cmd.Parameters.Add("@param1", SqlDbType.Int).Value = user.Id;
                SqlDataAdapter adpater = new SqlDataAdapter(cmd);
                DataSet data = new DataSet();
                adpater.Fill(data, "tblJeux");
                foreach (DataRow row in data.Tables[0].Rows)
                {
                    Jeux jeux = new Jeux();
                    jeux.Nom = row[0].ToString();
                    jeux.Chemin = row[1].ToString();
                    liste.Add(jeux);
                   
                }
                
            }
            catch(Exception e)
            {

            }
            return liste;
        }
    }
}
