﻿using Laboratoire6.Command;
using Laboratoire6.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace Laboratoire6.ViewModel
{
    class ListeJeuViewModel : BaseViewModel, INotifyPropertyChanged
    {
        private BaseCommand ajouterJeux;
        private BaseCommand lancerJeux;
        private Jeux jeux;
        private ObservableCollection<Button> listeb;
        private Utilisateur user;
        private ObservableCollection<Jeux> observeJeux;
       
        public ListeJeuViewModel(Utilisateur user)
        {
            this.user = user;
            afficherJeux();
            listeb = new ObservableCollection<Button>();
            Jeux = new Jeux();
            Predicate<object> canExecute = _ => true;
            Action<object> execute = _ => InsererJeux();
            ajouterJeux = new BaseCommand(execute, canExecute);
            
            lancerJeux = new BaseCommand(this.decollerJeux, canExecute);
            afficher();

        }
        
        public Jeux Jeux { get { return jeux; } set { jeux = value; } }
        public BaseCommand AjouterJeux { get { return ajouterJeux; } }
        public BaseCommand LancerJeux { get { return lancerJeux; } }

        public ObservableCollection<Jeux> ListeJeux{ get { return observeJeux; } set{ observeJeux = value; OnPropertyChanged("ListeJeux"); } }

        public ObservableCollection<Button> Listeb { get { return listeb; } set { listeb = value; OnPropertyChanged("Listeb"); } }

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
        public void afficherJeux()
        {
            ListeJeux = ChercherJeux(user);
        }
        public void InsererJeux()
        {
            Jeux.IdJoueur = user.Id;
          bool reussir =  InsererJeux(Jeux);
            if (reussir == true)
            {
                afficherJeux();
                MessageBox.Show("Jeux ajouté");
                
            }
            
        }

        public void decollerJeux(object emplacement)
        {
            Process.Start(emplacement.ToString()) ;
        }
        public void afficher()
        {
            foreach(Jeux jeu in ListeJeux)
            {
                Button b = new Button();
                b.CommandParameter = jeu.Chemin;
                b.Command = lancerJeux;
                b.Content = jeu.Nom;
                listeb.Add(b);
            }
        }
    }
}
